package com.example.app_inicial;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView etiqueta = new TextView(this);
        etiqueta.setText("CR7");
        TextView etiqueta2 = new TextView(this);
        etiqueta2.setText("Nano");
        Button boton = new Button(this);
        boton.setText("Anoeta es un futbolín");
        EditText muchoTexto = new EditText(this);
        TextView texto = new TextView(this);
        TextView numero = new TextView(this);
        numero.setText("0");

        TableLayout ellayout = new TableLayout(this);
        ellayout.setOrientation(LinearLayout.HORIZONTAL);
        ellayout.addView(etiqueta);
        ellayout.addView(etiqueta2);
        ellayout.addView(boton);
        ellayout.addView(muchoTexto);
        ellayout.addView(texto);
        ellayout.addView(numero);

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.setBackgroundColor(Color.BLUE);
                ellayout.setBackgroundColor(Color.RED);
                String textoEscrito= muchoTexto.getText().toString();
                int kont = Integer.parseInt(numero.getText().toString());
                kont = kont + 1;
                String kontString = String.valueOf(kont);
                numero.setText(kontString);
                texto.setText(textoEscrito);
            }
        });
        setContentView(ellayout);
    }

}